package BookStorePckg;

import java.util.*;


public class BookStore {
    private String name;
    private Customer customer;
    List<Book> books = new ArrayList<Book>();
    List<Book> searchResults = new ArrayList<Book>();
    List<Customer> customerList = new ArrayList<Customer>();
    HashMap<Customer, List<Book>> borrowedBooksMap = new HashMap<>();
    /**
     * Constructs and initializes Bookstore with name(name)
     * @param name  name of the bookstore
     */

    public BookStore(String name){
        this.name = name;
    }


    //starting value for timer
    String notificationText;
    int secondsPassed = 0;
    //customer borrows a book and timer starts

    /**
     * Borrows the book on the customer by storing info in lists and setting book availability to false
     * @param book book that is being borrowed
     * @param customer customer that is borrowing the book
     */
    public void borrowTheBook(Book book, Customer customer) {
            System.out.println("CALLING BORROW THE BOOK METHOD! BOOKSTORE");
            book.decreaseQuanity(1);
            customer.borrowedBooks.add(book);
            setBorrowedBooksMapBorrowed(customer, customer.borrowedBooks);
            System.out.println("Book: " + book.getTitle() + " will be borrowed by: " + customer.getName() + "!");
            Timer timer = new Timer();
            TimerTask task = new TimerTask() {
                @Override
                public void run() {
                    secondsPassed++;
                    //System.out.println(secondsPassed + customer.getName());
                    if (secondsPassed == 4) {
                        secondsPassed = 0;
                        timer.cancel();
                        System.out.println("---------------------------------------------------------------------");
                        System.out.println(customer + " is late with return of: " + customer.getBorrowedBooks());
                        System.out.println("---------------------------------------------------------------------");
                        //notificationText = borrowedBooksMap.toString() + "\n";
                        notificationText = printBorrowedBooksMap();
                        }
                    }
            };

            timer.scheduleAtFixedRate(task, 1000, 1000);
            task.run();
        if(!customerList.contains(customer)) {
            customerList.add(customer);
        }


    }

    /**
     * Getter for notification text of customer being late with return created in borrowTheBook method
     * @return
     */
    public String getNotificationText() {
        return notificationText;
    }

    //customer returns the book

    /**
     * Returns the book by deleting the book from customers borrowedBooks list and setting book availability to true
     * @param book book that is being returned
     * @param customer
     */
    public void returnTheBook(Book book, Customer customer){
        System.out.println("CALLING THE RETURN BOOK METHOD IN: BOOKSTORE");
        if(customer.borrowedBooks.contains(book)){
            customer.borrowedBooks.remove(book);
            book.increaseQuanity(1);
            setBorrowedBooksMapReturned(customer, book);
            //notificationText = borrowedBooksMap.toString();
            notificationText = printBorrowedBooksMap();
            System.out.println(customer.toString() + " is returning book: " + book.toString());
        }else {
            System.out.println(customer + " has not borrowed that book!");
        }


    }

    /**
     * Lists all the books in books list
     */
    public void listAllBooks(){
        System.out.println("Listing all books in bookstore: ");
        for (Book book : books) {
            System.out.println(book);
        }
    }

    /**
     * Adding book in books.list
     * @param book book that will be added to bookstore books list
     */
    public void addBookToBookStore(Book book){
        books.add(book);
        System.out.println(book.getTitle() + "; id= " + book.getBookID() + " successfully added!");
    }


    /**
     * Adding customer and customer.borrowedBooks
     * @param customer customer that has borrowed one or multiple books
     * @param borrowedBooks list of books borrowed by the customer
     */
    public void setBorrowedBooksMapBorrowed(Customer customer, List<Book> borrowedBooks){
        borrowedBooksMap.put(customer, borrowedBooks);
        System.out.println("Adding customer and his borrowed books to map!!!!!!!!!!");
    }

    /**
     * Removing the book or book and the customer from map of customers and books borrowed by them
     * @param customer customer that is returning the book
     * @param book book that is being returned
     */
    public void setBorrowedBooksMapReturned(Customer customer, Book book){
        customer.borrowedBooks.remove(book);
        if(customer.borrowedBooks.isEmpty()){
            borrowedBooksMap.remove(customer);
        }else {
            customer.borrowedBooks.remove(book);
            borrowedBooksMap.put(customer, customer.borrowedBooks);
        }

    }

    /**
     * Searching for book by id
     * @param id id that we are searching the book for
     */
    public void getBookByID(int id){
        searchResults.clear();
        for (Book book : books) {
            if (book.bookID == id) {
                System.out.println("Found a match! ->");
                System.out.println(book);
                searchResults.add(book);
            } else {
                System.out.println("Match not found!");
            }
        }
    }

    /**
     * Searching the book by title
     * @param title title that we are searching the book for
     */
    public void getBookByTitle(String title){
        searchResults.clear();
        for (Book book : books) {
            if (book.title.contains(title)) {
                System.out.println("Found a match! ->");
                System.out.println(book);
                searchResults.add(book);
            } else {
                System.out.println("Match not found!");
            }
        }
    }

    /**
     * Searching the book by author
     * @param author author that we are searching the book for
     */
    public void getBookByAuthor(String author){
        searchResults.clear();
        for (Book book : books) {
            if (book.author.contains(author)) {
                System.out.println("Found a match! ->");
                System.out.println(book);
                searchResults.add(book);
            } else {
                System.out.println("Match not found!");
            }
        }
    }

    /**
     * Getters for list of books
     * @return returns all the books added to bookstore
     */
    public List<Book> getBooks() {
        return books;
    }

    /**
     * Getters for search results
     * @return returns the search results
     */
    public List<Book> getSearchResults(){
        return searchResults;
    }

    /**
     * Getters for list of customers
     * @return returns the list of all the customers that had ever borrowed the book
     */
    public List<Customer> getCustomerList() {
        return customerList;
    }

    /**
     * Getters for borrowedBooksMap content
     * @return returns the map of customers that currently have borrowed books and books borrowed by them as string values
     */
    public String printBorrowedBooksMap() {
        String output = "";
        for (Customer customer : borrowedBooksMap.keySet()) {

            output +="OIB: " + customer.getOib() + " " +  " Name: " + customer.getName() + " is late with return: " + "\n" + Arrays.toString(customer.borrowedBooks.toArray()) + "\n";
            output += "\n";
        }
        return output;
    }

    /**
     * Getters for bookstore name
     * @return returns the name of the bookstore
     */
    public String getName() {
        return name;
    }
}
