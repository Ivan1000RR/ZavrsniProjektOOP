package BookStorePckg;

public class Book {
    /**
     * Book quantity
     */
    protected int quantity;
    /**
     * Book title
     */
    protected String title;
    protected String author;
    protected String genre;
    protected int bookID;
    protected static int cntID = 100;
    //protected boolean available = true;

    /**
     * Constructs and initializes book with unique id
     * @param title title of the book
     * @param author author of the book
     * @param genre genre of the book
     */
    public Book(String title, String author, String genre, int quantity){
        this.quantity = quantity;
        this.title = title;
        this.author = author;
        this.genre = genre;
        bookID = cntID;
        cntID++;
    }


    /**
     * Changes the availability of the book
     * @param available boolean value for book availability
     */
    /*
    public void setAvailable(boolean available) {
        this.available = available;
    }

     */

    /**
     * Getters for book title
     * @return returns title of the book
     */
    public String getTitle() {
        return title;
    }

    /**
     * Getters for book author
     * @return returns author of the book
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Getters for book genre
     * @return returns genre of the book
     */
    public String getGenre() {
        return genre;
    }

    /**
     * Getters for book id
     * @return returns id of the book
     */
    public int getBookID() {
        return bookID;
    }

    /**
     * Getters for book availability
     * @return returns availability of the book (boolean)
     */
    /*
    public boolean isAvailable() {

        return available;
    }
    */

    public void increaseQuanity(int inc){
        quantity += inc;
        System.out.println("Quantity increased!");
    }

    public void decreaseQuanity(int dec){
        quantity -= dec;
        System.out.println("Quantity decreased!");
    }

    public int getQuantity() {
        return quantity;
    }

    public void setNewQuantity(int q){
        int newQuantity = q;
    }

    @Override
    public String toString() {
        return "ID= " + bookID + '\'' +
                " title= " + title + '\'' +
                ", author= " + author + '\'' +
                ", genre= " + genre + '\'' +
                ", quanity= " + quantity +"\n";
    }

}
