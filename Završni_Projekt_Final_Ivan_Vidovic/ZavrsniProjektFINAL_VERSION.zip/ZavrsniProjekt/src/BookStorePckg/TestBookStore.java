package BookStorePckg;

public class TestBookStore {
    public static void main(String[] args) {
        BookStore bs = new BookStore("Bookstore1");
        Book book1 = new Book("Harry Potter", "J.K.R", "Fiction", 2);
        Book book2 = new Book("Harry Potter 2.dio", "J.K.R", "Fiction",3);
        bs.addBookToBookStore(book1);
        bs.addBookToBookStore(book2);

        System.out.println();
        bs.listAllBooks();

        Customer customer = new Customer("Ivan", "Vidovic", 312313, "0991234567");
        Customer customer2 = new Customer("Ivo", "Ivic", 1111312, "0991234567");


        System.out.println();

        System.out.println();
        System.out.println(" ************************* Customer borrows the book ************************* ");

        bs.borrowTheBook(book1, customer);
        bs.borrowTheBook(book2, customer);


        System.out.println(" ************************* Customer returns the book ************************* ");
        bs.returnTheBook(book1, customer);
        System.out.println(" ***************************************************************************** ");

        System.out.println(" ************************* Customer returns the book ************************* ");
        bs.returnTheBook(book1, customer);
        System.out.println(" ***************************************************************************** ");

        System.out.println(" ************************* Customer returns the book ************************* ");
        bs.returnTheBook(book2, customer2);
        System.out.println(" ***************************************************************************** ");



    }
}
