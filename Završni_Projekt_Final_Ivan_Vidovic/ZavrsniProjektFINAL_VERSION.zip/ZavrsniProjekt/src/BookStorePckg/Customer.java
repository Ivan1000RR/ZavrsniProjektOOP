package BookStorePckg;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String name;
    private String surname;
    private int oib;
    private String phone;
    List<Book> borrowedBooks = new ArrayList<Book>();


    /**
     * Constructs and initializes customer
     * @param name name of the customer
     * @param surname surname of the customer
     * @param oib oib of the customer
     * @param phone phone number of the customer
     */
    public Customer(String name, String surname, int oib, String phone){
        this.name = name;
        this.surname = surname;
        this.oib = oib;
        this.phone = phone;
    }

    /**
     * Getters for customers name
     * @return returns customers name
     */
    public String getName() {
        return name;
    }

    /**
     * Getters for customers surname
     * @return returns customers surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Getters for customers oib
     * @return returns customers oib
     */
    public int getOib() {
        return oib;
    }

    /**
     * Getters for customers lists of borrowed books
     * @return returns lists of borrowed books by the customer
     */
    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    /**
     * Customers toString method
     * @return returns customers attributes as string
     */
    @Override
    public String toString() {
        return "Customer{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", oib=" + oib +
                '}';
    }
}
