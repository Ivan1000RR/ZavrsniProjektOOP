package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TopPanel extends JPanel {
    JLabel titleLabel = new JLabel();
    JPanel loggedInPanel = new JPanel();
    JPanel toolBarPanel = new JPanel();
    private String username;


    TopPanel(String username){
        this.username = username;
        setLayout(new BorderLayout());
        setBackground(Color.gray);
        setPreferredSize(new Dimension(1400, 50));

        setDisplay();
        addContent();

    }

    public void setDisplay(){
        titleLabel.setFont(new Font("Serif", Font.ITALIC, 22));
        titleLabel.setForeground(Color.ORANGE);
        titleLabel.setBounds(0,0,100,50);
        titleLabel.setHorizontalAlignment(JLabel.CENTER);

        //***************Logged in panel with logout button**************
        loggedInPanel.setBackground(Color.lightGray);
        loggedInPanel.setLayout(null);
        loggedInPanel.setPreferredSize(new Dimension(300,50));
        //"USER: " label
        JLabel userLabel = new JLabel();
        userLabel.setBounds(5,0,50,50);
        userLabel.setText("USER:   ");
        loggedInPanel.add(userLabel);
        //show username
        JLabel userNameLabel = new JLabel();
        userNameLabel.setBackground(Color.lightGray);
        userNameLabel.setForeground(Color.white);
        userNameLabel.setText(username);
        userNameLabel.setBounds(50,0,100,50);
        loggedInPanel.add(userNameLabel);



        //**************************TOOLBAR PANEL********************
        toolBarPanel.setBackground(Color.gray);
        toolBarPanel.setPreferredSize(new Dimension(300,50));



    }

    public void addContent(){
        add(titleLabel);
        add(loggedInPanel, BorderLayout.WEST);
        add(toolBarPanel, BorderLayout.EAST);
    }
}
