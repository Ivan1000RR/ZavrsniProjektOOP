package GUI;

import javax.swing.*;
import java.awt.*;

public class AddingNewBookFrame extends JFrame{Container container=getContentPane();
    JLabel titleLabel=new JLabel("Title: ");
    JLabel authorLabel=new JLabel("Author: ");
    JLabel genreLabel =new JLabel("Genre: ");
    JLabel quantityLabel = new JLabel("Quantity");

    JTextField titleField =new JTextField();
    JTextField authorField =new JTextField();
    JTextField genreField = new JTextField();
    JTextField quanityField = new JTextField();

    JButton confirmButton=new JButton("Add book");

    /**
     * Constructs borrowed frame (form)
     */
    AddingNewBookFrame()
    {
        //Calling methods inside constructor.
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();

    }

    /**
     * Setting the layout manager
     */
    public void setLayoutManager()
    {
        container.setLayout(null);
    }

    /**
     * Setting the location and size of components
     */
    public void setLocationAndSize() {
        //Setting location and Size of each components using setBounds() method.
        titleLabel.setBounds(50,50,120,30);
        authorLabel.setBounds(50, 150, 120,30);
        genreLabel.setBounds(50,250,120,30);
        quantityLabel.setBounds(50, 300, 120, 30);

        titleField.setBounds(150,50,120,30);
        authorField.setBounds(150,150,120,30);
        genreField.setBounds(150,250,120,30);
        quanityField.setBounds(150, 300, 120, 30);


        confirmButton.setBounds(140,500, 120,35);


    }



    /**
     * Adding components to the container
     */
    public void addComponentsToContainer()
    {
        //Adding each components to the Container
        container.add(titleLabel);
        container.add(titleField);
        container.add(authorLabel);
        container.add(authorField);


        container.add(genreLabel);
        container.add(genreField);

        container.add(quantityLabel);
        container.add(quanityField);

        container.add(confirmButton);
    }


    /**
     * Sets the title, bounds, visibility and default close operation of the frame
     */
    public void init(){
        setTitle("Add new book Form");
        setVisible(true);
        setBounds(300,100,400,600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
    }

    /**
     * Getters for titleField data
     * @return returns data in titleField
     */
    public String getTitle() {
        return titleField.getText();
    }

    /**
     * Getters for authorField data
     * @return returns data in authorField
     */
    public String getAuthor() {
        return authorField.getText();
    }

    /**
     * Getters for genreField data
     * @return returns data in genreField as Integer value
     */
    public String getGenre() {
        return genreField.getText();
    }

    public Integer getQuanityField() {
        return Integer.valueOf(quanityField.getText());
    }
}

