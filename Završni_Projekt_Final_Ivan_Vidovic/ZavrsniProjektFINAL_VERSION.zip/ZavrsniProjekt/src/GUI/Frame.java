package GUI;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.*;
import java.util.List;
import java.util.Timer;

import BookStorePckg.*;


public class Frame extends JFrame implements ActionListener {

    int secondsPassed = 0;
    List<Integer> customersOibs = new ArrayList<Integer>();

    /**
     * Constructs main frame of the bookstore application with all of it's sub-frames
     * @param username username of the current user
     */
    public Frame(String username){
        super("BookStore application");

        BookStore bs = new BookStore("Book Store");
        Book book = new Book( "Harry Potter", "J.K.R", "Fiction", 2);

        Book book2 = new Book( "Harry Potter 2.dio", "J.K.R", "Fiction", 1);

        Book book3 = new Book( "Snow White", "Grimm", "Tale", 2);
        Book book4 = new Book( "Snow White", "UNKNOWN", "Tale", 5);

        Book book5 = new Book( "Fairy Tale", "Stephen King", "Triler", 2);

        Book book7 = new Book( "Moby Dick", "Herman Melville", "Fiction", 3);

        Book book10 = new Book( "Hamlet", "William Shakespeare", "Tragedy/Drama", 1);

        bs.addBookToBookStore(book);
        bs.addBookToBookStore(book2);
        bs.addBookToBookStore(book3);
        bs.addBookToBookStore(book5);
        bs.addBookToBookStore(book7);
        bs.addBookToBookStore(book10);
        bs.addBookToBookStore(book4);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10,10));
        ImageIcon logoImage = new ImageIcon("logo.png");
        setIconImage(logoImage.getImage());
        setVisible(true);



        //****************************nav bar****************************

        TopPanel topPanel = new TopPanel(username);
        topPanel.titleLabel.setText(bs.getName());
        add(topPanel, BorderLayout.NORTH);


        //logOut button
        JButton logoutBtn = new JButton();
        logoutBtn.setText("LogOut");
        logoutBtn.setHorizontalAlignment(JButton.CENTER);
        logoutBtn.setBounds(120,25,90,20);
        topPanel.loggedInPanel.add(logoutBtn);


        //toggleButton
        JToggleButton toggleButton = new JToggleButton();
        toggleButton.setVerticalAlignment(JButton.CENTER);
        toggleButton.setHorizontalAlignment(JButton.LEFT);
        toggleButton.setText("Listing all");



        //Add new book button
        JButton addBookButton = new JButton();
        addBookButton.setVerticalAlignment(JButton.CENTER);
        addBookButton.setHorizontalAlignment(JButton.CENTER);
        addBookButton.setText("Add book");


        //Remove existing book button
        JButton removeBookBtn = new JButton();
        removeBookBtn.setVerticalAlignment(JButton.CENTER);
        removeBookBtn.setHorizontalAlignment(JButton.RIGHT);
        removeBookBtn.setText("Remove book");

        //toolbar
        JToolBar toolBar = new JToolBar();
        toolBar.add(toggleButton);
        toolBar.add(addBookButton);
        toolBar.add(removeBookBtn);

        topPanel.toolBarPanel.add(toolBar);



        //****************************main panel****************************

        CenterPanel centerPanel = new CenterPanel();
        add(centerPanel, BorderLayout.CENTER);


        //init notification
        JTextPane lateWithReturn = new JTextPane();
        lateWithReturn.setForeground(Color.red);

        //Options
        Object[] optionsDialog = {"Borrow", "Return", "Exit"};
        //*****************************************************************************************************



        //****************ListOfAllBooks or ListBorrowed Panel --- main print + Borrow and return ************************+

        DefaultListModel listModel = new DefaultListModel();
        //setting default data!
        for(int i = 0; i < bs.getBooks().size(); i++){
            listModel.add(i, bs.getBooks().get(i));
        }
        JList<Book> listOfBooks = new JList<>(listModel);
        JScrollPane jScrollPane = new JScrollPane(listOfBooks);
        TitledBorder titledBorderMain = BorderFactory.createTitledBorder("Main Screen");
        titledBorderMain.setTitleJustification(TitledBorder.CENTER);
        jScrollPane.setBorder(titledBorderMain);

        toggleButton.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                listModel.clear();
                if(toggleButton.isSelected()){
                    System.out.println("SELECTED");
                    toggleButton.setText("Listing borrowed");
                    List<Book> borrowedBooks = new ArrayList<>();
                    for(int j = 0; j < bs.getCustomerList().size(); j++){
                        bs.getCustomerList().get(j).getBorrowedBooks();
                        for(int x = 0; x < bs.getCustomerList().get(j).getBorrowedBooks().size(); x++ ){
                            borrowedBooks.add(bs.getCustomerList().get(j).getBorrowedBooks().get(x));
                        }
                    }
                    /*
                    for (int i = 0; i < bs.getBooks().size(); i++) {
                        if (!bs.getBooks().get(i).getQuantity()) {
                            borrowedBooks.add(bs.getBooks().get(i));

                        }
                    }

                     */
                    for(int i = 0; i < borrowedBooks.size(); i++){
                        listModel.add(i, borrowedBooks.get(i));
                    }
                    borrowedBooks.clear();

                }else {
                    System.out.println("NOT SELECTED");
                    toggleButton.setText("Listing all");
                    for(int i = 0; i < bs.getBooks().size(); i++){
                        listModel.add(i, bs.getBooks().get(i));
                    }

                }
            }
        });



        listOfBooks.addListSelectionListener(e -> {
                if(listOfBooks.getSelectedValue() == null){
                    return;
                }
                int n = JOptionPane.showOptionDialog(jScrollPane, "Quantity: " + listOfBooks.getSelectedValue().getQuantity() + "\n" + "Choose option: ",
                        "Options",
                        JOptionPane.YES_NO_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        optionsDialog,
                        optionsDialog[2]);
                System.out.println("Choice = " + n);
                if (n == 0) {

                    BorrowFrame borrowFrame = new BorrowFrame();
                    borrowFrame.init();
                    borrowFrame.confirmButton.addActionListener(e1 -> {
                        try {
                            if (bs.getCustomerList().isEmpty() || !customersOibs.contains(borrowFrame.getOib()) && bs.getBooks().get(listOfBooks.getSelectedIndex()).getQuantity() != 0) {
                                customersOibs.add(borrowFrame.getOib());
                                Customer customer = new Customer((borrowFrame.getName()), borrowFrame.getSurname(), borrowFrame.getOib(), borrowFrame.getPhone());
                                System.out.println("SELECTED BOOK:(Borrow) " + bs.getBooks().get(listOfBooks.getSelectedIndex()));
                                System.out.println("Borrowing on the new customer: " + customer.toString());
                                //bs.borrowTheBook(bs.getBooks().get(listOfBooks.getSelectedIndex()), customer);
                                bs.borrowTheBook(listOfBooks.getSelectedValue(), customer);
                                Timer timer = new Timer();
                                TimerTask task = new TimerTask() {
                                    @Override
                                    public void run() {
                                        secondsPassed++;
                                        if (secondsPassed == 6) {
                                            secondsPassed = 0;
                                            lateWithReturn.setText(bs.getNotificationText());
                                            timer.cancel();
                                        }
                                    }
                                };
                                timer.scheduleAtFixedRate(task, 1000, 1000);
                                task.run();
                            } else if (customersOibs.contains(borrowFrame.getOib()) && bs.getBooks().get(listOfBooks.getSelectedIndex()).getQuantity() != 0) {
                                System.out.println("Print customer");
                                System.out.println("SELECTED BOOK(Borrow): " + bs.getBooks().get(listOfBooks.getSelectedIndex()));
                                System.out.println("Borrowing on the existing customer: ");
                                for (int i = 0; i < bs.getCustomerList().size(); i++) {
                                    if (borrowFrame.oibField.getText().equals(String.valueOf(bs.getCustomerList().get(i).getOib()))) {
                                        System.out.println("Trying to borrow after loop to: " + bs.getCustomerList().get(i).toString());
                                        bs.borrowTheBook(listOfBooks.getSelectedValue(), bs.getCustomerList().get(i));
                                        Timer timer = new Timer();
                                        TimerTask task = new TimerTask() {
                                            @Override
                                            public void run() {
                                                secondsPassed++;
                                                if (secondsPassed == 6) {
                                                    secondsPassed = 0;
                                                    //lateWithReturn.setText(bs.getBorrowedBooksMap().toString());
                                                    lateWithReturn.setText(bs.getNotificationText());
                                                    timer.cancel();
                                                }
                                            }
                                        };
                                        timer.scheduleAtFixedRate(task, 1000, 1000);
                                        task.run();


                                    }
                                }

                            } else {
                                System.out.println("Book is not available! FRAME");
                                JOptionPane.showMessageDialog(borrowFrame ,"Book is not available!");
                            }
                            borrowFrame.dispose();
                            listOfBooks.clearSelection();
                        }catch (NumberFormatException numberFormatException){
                            System.out.println("Blank input");
                            JOptionPane.showMessageDialog(borrowFrame, "BLANK INPUT");
                        }

                        });


                }
                if (n == 1) {
                    System.out.println("SELECTED BOOK(Return): " + listOfBooks.getSelectedValue());
                    System.out.println(listOfBooks.getSelectedValue().getQuantity());
                    ReturnFrame returnFrame = new ReturnFrame();
                    returnFrame.init();
                    returnFrame.confirmButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                int oib = returnFrame.getOib();
                                if (customersOibs.contains(oib)) {
                                    for (int i = 0; i < bs.getCustomerList().size(); i++) {
                                        if (bs.getCustomerList().get(i).getOib() == oib) {
                                            System.out.println("Found a match! -> ");
                                            System.out.println(bs.getCustomerList().get(i).toString());
                                            bs.returnTheBook(listOfBooks.getSelectedValue(), bs.getCustomerList().get(i));
                                            lateWithReturn.setText(bs.getNotificationText());
                                            }
                                            break;
                                        }

                                } else {
                                    System.out.println("There is no customer with oib: " + oib);
                                    JOptionPane.showMessageDialog(returnFrame, "WRONG INPUT!");
                                }
                                returnFrame.dispose();
                                listOfBooks.clearSelection();
                            } catch (NumberFormatException numberFormatException) {
                                System.out.println("Blank input");
                                JOptionPane.showMessageDialog(returnFrame, "BLANK INPUT");
                            }
                        }

                    });


                }


            });


        centerPanel.add(jScrollPane, BorderLayout.CENTER);



        //------------------display search results + Borrow and return *****************************
        //----------Search panel

        JPanel comboBoxPanel = new JPanel();

        TitledBorder comboboxpanelBorder = BorderFactory.createTitledBorder("Search books");
        comboboxpanelBorder.setTitleJustification(TitledBorder.CENTER);
        comboboxpanelBorder.setTitleColor(Color.white);

        comboBoxPanel.setBackground(Color.gray);
        comboBoxPanel.setPreferredSize(new Dimension(500,100));
        comboBoxPanel.setBorder(comboboxpanelBorder);
        String[] options = {"Search by ID", "Search by title", "Search by author"};



        JComboBox comboBox = new JComboBox(options);
        comboBox.setBackground(Color.gray);
        comboBox.setEditable(true);
        comboBox.setSelectedItem("Select search option...");
        comboBox.setEditable(false);
        comboBox.setPreferredSize(new Dimension(200,30));
        comboBox.setBackground(Color.lightGray);
        comboBoxPanel.add(comboBox);
        centerPanel.add(comboBoxPanel, BorderLayout.WEST);


        DefaultListModel model = new DefaultListModel();
        JList<Book> searchResultsPrint = new JList(model);
        JScrollPane jScrollPane1 = new JScrollPane(searchResultsPrint);

        jScrollPane1.setPreferredSize(new Dimension(490,450));


        comboBoxPanel.add(jScrollPane1);

        //combo box listener
        comboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.clear();
                System.out.println("SELECTED: " + comboBox.getSelectedItem());
                if(comboBox.getSelectedIndex() == 0){
                    try {
                        String id = JOptionPane.showInputDialog("Enter id:");
                        bs.getBookByID(Integer.parseInt(id));
                        for (int i = 0; i < bs.getSearchResults().size(); i++) {
                            model.add(i, bs.getSearchResults().get(i));
                        }
                    }catch (NumberFormatException numberFormatException){
                        System.out.println("Wrong input!");
                    }
                }else if(comboBox.getSelectedIndex() == 1){
                    String title = JOptionPane.showInputDialog("Enter title:");
                    bs.getBookByTitle(title);
                    for(int i = 0; i<bs.getSearchResults().size(); i++){
                        model.add(i, bs.getSearchResults().get(i));
                    }

                }else if(comboBox.getSelectedIndex() == 2){
                    String author = JOptionPane.showInputDialog("Enter author name:");
                    bs.getBookByAuthor(author);
                    for(int i = 0; i<bs.getSearchResults().size(); i++){
                        model.add(i, bs.getSearchResults().get(i));
                    }
                }
            }
        });

        //-------------------------Search results borrow and return------------------------------

        searchResultsPrint.addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent e) {
                if(searchResultsPrint.getSelectedValue() == null){
                    return;
                }
                    int n = JOptionPane.showOptionDialog(jScrollPane1, "Quantity = " + searchResultsPrint.getSelectedValue().getQuantity()  + "\n" + "Choose option: ",
                            "Options",
                            JOptionPane.YES_NO_CANCEL_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            optionsDialog,
                            optionsDialog[2]);
                    System.out.println("Choice = " + n);
                    if (n == 0) {
                        BorrowFrame borrowFrame = new BorrowFrame();
                        borrowFrame.init();
                        borrowFrame.confirmButton.addActionListener(e1 -> {
                            try {
                                if (bs.getCustomerList().isEmpty() || !customersOibs.contains(borrowFrame.getOib()) && searchResultsPrint.getSelectedValue().getQuantity() != 0) {
                                    customersOibs.add(borrowFrame.getOib());
                                    Customer customer = new Customer((borrowFrame.getName()), borrowFrame.getSurname(), borrowFrame.getOib(), borrowFrame.getPhone());
                                    System.out.println("SELECTED BOOK:(Borrow) " + searchResultsPrint.getSelectedValue());
                                    System.out.println("Borrowing on the new customer: " + customer.toString());
                                    bs.borrowTheBook(searchResultsPrint.getSelectedValue(), customer);
                                    Timer timer = new Timer();
                                    TimerTask task = new TimerTask() {
                                        @Override
                                        public void run() {
                                            secondsPassed++;
                                            if (secondsPassed == 6) {
                                                secondsPassed = 0;
                                                lateWithReturn.setText(bs.getNotificationText());
                                                timer.cancel();
                                            }
                                        }
                                    };
                                    timer.scheduleAtFixedRate(task, 1000, 1000);
                                    task.run();
                                } else if (customersOibs.contains(borrowFrame.getOib()) && searchResultsPrint.getSelectedValue().getQuantity() != 0) {
                                    System.out.println("SELECTED BOOK(Borrow): " + searchResultsPrint.getSelectedValue());
                                    System.out.println("Borrowing on the existing customer: ");
                                    for (int i = 0; i < bs.getCustomerList().size(); i++) {
                                        if (borrowFrame.oibField.getText().equals(String.valueOf(bs.getCustomerList().get(i).getOib()))) {
                                            bs.borrowTheBook(searchResultsPrint.getSelectedValue(), bs.getCustomerList().get(i));
                                            Timer timer = new Timer();
                                            TimerTask task = new TimerTask() {
                                                @Override
                                                public void run() {
                                                    secondsPassed++;
                                                    if (secondsPassed == 6) {
                                                        secondsPassed = 0;
                                                        lateWithReturn.setText(bs.getNotificationText());
                                                        timer.cancel();
                                                    }
                                                }
                                            };
                                            timer.scheduleAtFixedRate(task, 1000, 1000);
                                            task.run();


                                        }
                                    }


                                } else {
                                    System.out.println("Book is not available! FRAME");
                                }
                                borrowFrame.dispose();
                                searchResultsPrint.clearSelection();

                            } catch (NumberFormatException ie) {
                                System.out.println("Blank input");
                                JOptionPane.showMessageDialog(borrowFrame, "BLANK INPUT");
                            }

                        });

                    }
                    if (n == 1) {
                        System.out.println("SELECTED BOOK(Return): " + searchResultsPrint.getSelectedValue());
                        ReturnFrame returnFrame = new ReturnFrame();
                        returnFrame.init();
                        returnFrame.confirmButton.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                try {
                                    int oib = returnFrame.getOib();
                                    if (customersOibs.contains(oib)) {
                                        for (int i = 0; i < bs.getCustomerList().size(); i++) {
                                            if (bs.getCustomerList().get(i).getOib() == oib) {
                                                System.out.println("Found a match! -> ");
                                                System.out.println(bs.getCustomerList().get(i).toString());
                                                bs.returnTheBook(searchResultsPrint.getSelectedValue(), bs.getCustomerList().get(i));
                                                lateWithReturn.setText(bs.getNotificationText());
                                                break;
                                            }
                                        }
                                    } else {
                                        System.out.println("There is no customer with oib: " + oib);
                                        JOptionPane.showMessageDialog(returnFrame, "WRONG INPUT!");
                                    }
                                    returnFrame.dispose();
                                    searchResultsPrint.clearSelection();
                                }catch (NumberFormatException numberFormatException){
                                    System.out.println("Blank input");
                                    JOptionPane.showMessageDialog(returnFrame, "BLANK INPUT");
                                }
                            }

                        });


                    }

            }
        });




        //****************************notification panel****************************


        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.lightGray);
        rightPanel.setLayout(new BorderLayout());
        rightPanel.setPreferredSize(new Dimension(300,100));



        JPanel notificationPanel = new JPanel();
        TitledBorder border = BorderFactory.createTitledBorder("Notifications");
        border.setTitleJustification(TitledBorder.CENTER);
        border.setTitleColor(Color.white);
        notificationPanel.setBorder(border);
        notificationPanel.setBackground(Color.gray);
        notificationPanel.setLayout(new BorderLayout());
        notificationPanel.setPreferredSize(new Dimension(300,250));

        rightPanel.add(notificationPanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);


        lateWithReturn.setEditable(false);
        JScrollPane notificationPane = new JScrollPane(lateWithReturn);
        notificationPane.setPreferredSize(new Dimension(50,200));
        notificationPanel.add(notificationPane, BorderLayout.CENTER);


        //***************************ACTIONS********************************

        //Logout button -- calls loginForm
        logoutBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Logged out successfully!");
                LoginFrame frame=new LoginFrame();
                frame.setTitle("Login Form");
                frame.setVisible(true);
                frame.setBounds(10,10,370,600);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setResizable(false);
                setVisible(false);

            }
        });

        //addBookButton event listener -- calls addNewBookFrame
        addBookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddingNewBookFrame addingNewBookFrame = new AddingNewBookFrame();
                addingNewBookFrame.init();
                addingNewBookFrame.confirmButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(!addingNewBookFrame.getTitle().isEmpty() && !addingNewBookFrame.getAuthor().isEmpty() && !addingNewBookFrame.getGenre().isEmpty()) {
                            Book newBook = new Book(addingNewBookFrame.getTitle(), addingNewBookFrame.getAuthor(), addingNewBookFrame.getGenre(), addingNewBookFrame.getQuanityField());
                            bs.addBookToBookStore(newBook);
                            System.out.println("Book: " + newBook.toString() + " has been added!");
                            listModel.clear();
                            for (int i = 0; i < bs.getBooks().size(); i++) {
                                listModel.add(i, bs.getBooks().get(i));
                            }
                            addingNewBookFrame.dispose();
                        }else{
                            System.out.println("Empty input!");
                            JOptionPane.showMessageDialog(addingNewBookFrame, "WRONG INPUT!");
                        }
                    }
                });
            }
        });

        //removeBook button action listener
        removeBookBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RemoveBookFrame removeBookFrame = new RemoveBookFrame();
                removeBookFrame.init();
                removeBookFrame.confirmButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                            try {
                                for(int i = 0; i < bs.getBooks().size(); i++) {
                                    if (bs.getBooks().get(i).getBookID() == removeBookFrame.getID()) {
                                        if(bs.getBooks().get(i).getQuantity() > 1) {
                                            bs.getBooks().get(i).decreaseQuanity(1);
                                        }else if( bs.getBooks().get(i).getQuantity() == 1) {
                                            bs.getBooks().remove(i);
                                        }
                                        System.out.println("Book successfully removed!");
                                        listModel.clear();
                                        for (int j = 0; j < bs.getBooks().size(); j++) {
                                            listModel.add(j, bs.getBooks().get(j));
                                        }
                                        removeBookFrame.dispose();


                                    }
                                }
                            }catch (NumberFormatException numberFormatException){
                                System.out.println("Wrong input!");
                                JOptionPane.showMessageDialog(removeBookFrame, "WRONG INPUT!");

                            }
                    }
                });
            }
        });

    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }
}
