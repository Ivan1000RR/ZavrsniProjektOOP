package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class LoginFrame extends JFrame implements ActionListener {

    Container container=getContentPane();
    JLabel userLabel=new JLabel("USERNAME");
    JLabel passwordLabel=new JLabel("PASSWORD");
    JTextField userTextField=new JTextField();
    JPasswordField passwordField=new JPasswordField();
    JButton loginButton=new JButton("LOGIN");
    JButton resetButton=new JButton("RESET");
    JCheckBox showPassword=new JCheckBox("Show Password");

    User user = new User("Admin", "admin");

    /**
     * Constructs login frame (form)
     */
    LoginFrame()
    {
        //Calling methods inside constructor.
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();

    }

    /**
     * Setting the layout manager
     */
    public void setLayoutManager()
    {
        container.setLayout(null);
    }

    /**
     * Setting the location and size of components
     */
    public void setLocationAndSize()
    {
        //Setting location and Size of each components using setBounds() method.
        userLabel.setBounds(50,150,100,30);
        passwordLabel.setBounds(50,220,100,30);
        userTextField.setBounds(150,150,150,30);
        passwordField.setBounds(150,220,150,30);
        showPassword.setBounds(150,250,150,30);
        loginButton.setBounds(50,300,100,30);
        resetButton.setBounds(200,300,100,30);


        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Resetting fields!");
                userTextField.setText(null);
                passwordField.setText(null);
            }
        });


        showPassword.addItemListener(new ItemListener() {
            char def = passwordField.getEchoChar();
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange() == ItemEvent.SELECTED){
                    System.out.println("Showing password field chars");
                    passwordField.setEchoChar((char) 0);
                }else {
                    System.out.println("Not showing password field chars");
                    passwordField.setEchoChar(def);
                }
            }
        });


        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (userTextField.getText().equals(user.getUsername()) & passwordField.getText().equals(user.getPassword())) {
                    System.out.println("Logged in successfully!");
                    System.out.println(user.getUsername());
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            Frame frame = new Frame(user.getUsername());
                            frame.setSize(1400, 600);
                            frame.setResizable(false);
                        }
                    });

                    setVisible(false);


                }else {

                    System.out.println("Wrong username or password!");
                    JOptionPane.showInternalMessageDialog(container, "Wrong username or password!");
                    userTextField.setText(null);
                    passwordField.setText(null);
                }
            }
        });

    }

    /**
     * Adding components to the container
     */
    public void addComponentsToContainer()
    {
        //Adding each components to the Container
        container.add(userLabel);
        container.add(passwordLabel);
        container.add(userTextField);
        container.add(passwordField);
        container.add(showPassword);
        container.add(loginButton);
        container.add(resetButton);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
