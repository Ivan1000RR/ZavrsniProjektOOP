package GUI;

import javax.swing.*;
import java.awt.*;

public class CenterPanel extends JPanel {

    /**
     * Constructs center panel
     */
    CenterPanel(){
        setBackground(Color.white);
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(100,100));

    }

}
