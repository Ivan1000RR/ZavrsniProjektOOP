package GUI;

import javax.swing.*;
import java.awt.*;

public class BorrowFrame extends JFrame {
    Container container=getContentPane();
    JLabel nameLabel=new JLabel("NAME");
    JLabel surnameLabel=new JLabel("SURNAME");
    JLabel oibLabel=new JLabel("OIB");
    JLabel phoneLabel=new JLabel("PHONE");

    JTextField nameField=new JTextField();
    JTextField surnameField=new JTextField();
    JTextField oibField = new JTextField();
    JTextField phoneField = new JTextField();

    JButton confirmButton=new JButton("CONFIRM");

    /**
     * Constructs borrowed frame (form)
     */
    BorrowFrame()
    {
        //Calling methods inside constructor.
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();

    }

    /**
     * Setting the layout manager
     */
    public void setLayoutManager()
    {
        container.setLayout(null);
    }

    /**
     * Setting the location and size of components
     */
    public void setLocationAndSize() {
        //Setting location and Size of each components using setBounds() method.
        nameLabel.setBounds(50,50,120,30);
        surnameLabel.setBounds(50, 150, 120,30);
        oibLabel.setBounds(50,250,120,30);
        phoneLabel.setBounds(50,350,120,30);

        nameField.setBounds(150,50,120,30);
        surnameField.setBounds(150,150,120,30);
        oibField.setBounds(150,250,120,30);
        phoneField.setBounds(150,350,120,30);

        confirmButton.setBounds(140,500, 120,35);

    }

    /**
     * Adding components to the container
     */
    public void addComponentsToContainer()
    {
        //Adding each components to the Container
        container.add(nameLabel);
        container.add(nameField);
        container.add(surnameLabel);
        container.add(surnameField);
        container.add(oibLabel);
        container.add(oibField);
        container.add(phoneLabel);
        container.add(phoneField);
        container.add(confirmButton);
    }

    /**
     * Sets the title, bounds, visibility and default close operation of the frame
     */
    public void init(){
        setTitle("Borrow Form");
        setVisible(true);
        setBounds(300,100,400,600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setResizable(false);
    }

    /**
     * Getters for nameField data
     * @return returns data in nameField
     */
    public String getName() {
        return nameField.getText();
    }

    /**
     * Getters for surnameField data
     * @return returns data in surnameField
     */
    public String getSurname() {
        return surnameField.getText();
    }

    /**
     * Getters for idField data
     * @return returns data in idField as Integer value
     */
    public Integer getOib() {
        return Integer.valueOf(oibField.getText());
    }

    /**
     * Getters for phoneField data
     * @return returns data in phoneField
     */
    public String getPhone() {
        return phoneField.getText();
    }
}
