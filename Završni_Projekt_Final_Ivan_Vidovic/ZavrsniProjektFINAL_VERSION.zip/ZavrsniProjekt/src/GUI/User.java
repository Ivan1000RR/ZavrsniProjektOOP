package GUI;

public class User {
    private String username;
    private String password;
    private int userID;
    private static int cntID = 1;

    /**
     * Constructs and initializes user of the application and adds unique id to each
     * @param username username for the user
     */
    public User(String username, String password){
        this.username = username;
        this.password = password;
        userID = cntID;
        cntID++;
    }

    /**
     * Getters for users username
     * @return returns users username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Getters for users username
     * @return returns users password
     */
    public String getPassword() {
        return password;
    }
}
