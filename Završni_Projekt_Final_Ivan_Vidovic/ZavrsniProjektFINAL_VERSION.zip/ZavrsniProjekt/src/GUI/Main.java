package GUI;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                System.out.println("Starting bookstore application");
                LoginFrame frame=new LoginFrame();
                frame.setTitle("Login Form");
                frame.setVisible(true);

                frame.setBounds(300,100,375,450);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setResizable(false);
            }
        });



    }
}
