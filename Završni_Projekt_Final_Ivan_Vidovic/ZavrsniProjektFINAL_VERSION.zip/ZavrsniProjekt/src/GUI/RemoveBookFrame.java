package GUI;

import javax.swing.*;
import java.awt.*;

public class RemoveBookFrame extends JFrame {
    Container container=getContentPane();

    JLabel idLabel =new JLabel("BookID:");

    JTextField idField = new JTextField();


    JButton confirmButton=new JButton("Remove");

    /**
     * Constructs return frame (form)
     */
    RemoveBookFrame()
    {
        //Calling methods inside constructor.
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();

    }

    /**
     * Setting the layout manager
     */
    public void setLayoutManager()
    {
        container.setLayout(null);
    }

    /**
     * Setting the location and size of components
     */
    public void setLocationAndSize() {
        //Setting location and Size of each components using setBounds() method.
        idLabel.setBounds(10,150,70,30);

        idField.setBounds(100,150,90,30);

        confirmButton.setBounds(100,220, 120,35);

    }

    /**
     * Adding components to the container
     */
    public void addComponentsToContainer()
    {
        //Adding each components to the Container
        container.add(idLabel);
        container.add(idField);
        container.add(confirmButton);
    }

    /**
     * Sets the title, bounds, visibility and default close operation of the frame
     */
    public void init(){
        setTitle("Remove Form");
        setVisible(true);
        setBounds(300,100,250,350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }


    /**
     * Getters for idField data
     * @return returns data in idField as Integer value
     */
    public Integer getID() {
        return Integer.parseInt(idField.getText());
    }


}


